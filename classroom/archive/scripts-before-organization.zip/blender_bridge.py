import argparse
import json
from pathlib import Path
from blmcp.tools_helpers.connection import send_code

parser = argparse.ArgumentParser()
parser.add_argument('script')
args = parser.parse_args()
response = send_code(Path(args.script).read_text(encoding='utf-8-sig'), strict_json=False)
print(json.dumps(response, indent=2))
if response.get('status') != 'ok':
    raise SystemExit(1)
