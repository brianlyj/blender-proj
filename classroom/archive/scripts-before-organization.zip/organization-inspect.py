import bpy,os
result={'filepath':bpy.data.filepath,'dirty':bpy.data.is_dirty,'images':[{'name':i.name,'path':i.filepath,'packed':bool(i.packed_file),'source':i.source} for i in bpy.data.images if i.source=='FILE'],'libraries':[l.filepath for l in bpy.data.libraries]}
