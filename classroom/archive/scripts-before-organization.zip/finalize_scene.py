import bpy, json, math
from pathlib import Path
s=bpy.context.scene;rig=bpy.data.objects['CHARACTER_RIG | select to pose']
s.frame_set(1);a={b.name:b.matrix.copy() for b in rig.pose.bones}
s.frame_set(120);loop_error=max(abs(rig.pose.bones[n].matrix[i][j]-a[n][i][j]) for n in a for i in range(4) for j in range(4))
unweighted=[]
for ob in rig.children:
    if ob.type=='MESH' and any(not v.groups for v in ob.data.vertices):unweighted.append(ob.name)
reference=Path(r'C:\Users\ASUS\AppData\Local\Temp\codex-clipboard-5a6ef3ce-e2bf-4530-baac-ec52ff10f487.png')
im=bpy.data.images.load(str(reference),check_existing=True);im.name='Character reference | supplied image';im.pack()
s.frame_set(16)
notes=bpy.data.texts.get('START HERE | Classroom and character')
notes.write('\nFINAL VALIDATION\n49 bones; 175 skinned mesh components; individual fingers and toe deformation; 12 eye meshes with Blink shape keys.\nReference image is packed in this .blend file.\nAnimation length: five seconds (frames 1-120 at 24 fps).\n')
bpy.ops.wm.save_as_mainfile(filepath=r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom\Classroom.blend')
result={'loop_max_matrix_difference':loop_error,'unweighted_meshes':unweighted,'reference_packed':bool(im.packed_file),'skinned_components':len([o for o in rig.children if o.type=='MESH']),'file':bpy.data.filepath}

