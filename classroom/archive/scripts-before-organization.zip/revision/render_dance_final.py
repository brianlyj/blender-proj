import bpy
from pathlib import Path
root=Path(r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom\revision');frames=root/'dance_frames';frames.mkdir(exist_ok=True)
s=bpy.data.scenes['Classroom | Golden Hour'];s.camera=bpy.data.objects['Camera | 10 second dance'];s.render.engine='BLENDER_EEVEE';s.render.resolution_x=720;s.render.resolution_y=960;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG'
if hasattr(s,'eevee') and hasattr(s.eevee,'taa_render_samples'):s.eevee.taa_render_samples=32
for label,frame in [('Rest-clasped',1),('Dance-preview',69)]:
 s.frame_set(frame);s.render.filepath=str(root/(label+'.png'));bpy.ops.render.render(write_still=True,scene=s.name)
s.render.resolution_x=640;s.render.resolution_y=848
if hasattr(s,'eevee') and hasattr(s.eevee,'taa_render_samples'):s.eevee.taa_render_samples=16
for frame in range(1,241):
 s.frame_set(frame);s.render.filepath=str(frames/('frame_%03d.png'%(frame-1)));bpy.ops.render.render(write_still=True,scene=s.name)
 if frame%24==0:print('DANCE_SECOND',frame//24,'/10',flush=True)
