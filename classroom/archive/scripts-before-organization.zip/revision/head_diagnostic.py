import bpy,math
from mathutils import Vector
from pathlib import Path
r=Path(r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom\revision');s=bpy.data.scenes['Classroom | Golden Hour'];rig=bpy.data.objects['MARI | refined character rig'];s.frame_set(1)
# Temporary close-up cameras in the background process only.
d=bpy.data.cameras.new('Diagnostic');c=bpy.data.objects.new('Diagnostic',d);s.collection.objects.link(c);d.type='ORTHO';d.ortho_scale=1.06;s.camera=c
s.render.resolution_x=750;s.render.resolution_y=800;s.render.resolution_percentage=100
for label,delta in [('front',(0,-3,.05)),('side',(3,-.1,.05))]:
 target=rig.location+Vector((0,.03,1.88));c.location=target+Vector(delta);c.rotation_euler=(target-c.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(r/('Head-before-'+label+'.png'));bpy.ops.render.render(write_still=True,scene=s.name)
