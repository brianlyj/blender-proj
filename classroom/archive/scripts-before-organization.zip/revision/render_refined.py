import bpy
from pathlib import Path
root=Path(r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom\revision')
s=bpy.data.scenes['Classroom | Golden Hour'];s.frame_set(16)
s.camera=bpy.data.objects['Camera | character portrait'];s.render.resolution_x=900;s.render.resolution_y=1150;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.filepath=str(root/'Character-refined-preview.png')
bpy.ops.render.render(write_still=True,scene=s.name)

s.frame_set(39);s.render.filepath=str(root/'Character-blink-check.png');bpy.ops.render.render(write_still=True,scene=s.name)

