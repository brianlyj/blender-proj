import bpy,json
r=bpy.data.objects['MARI | refined character rig'];c=bpy.data.collections['05 Character | refined sports outfit'];s=bpy.context.scene
result={'bones':{b.name:{'head':list(b.head_local),'tail':list(b.tail_local),'parent':b.parent.name if b.parent else None,'length':b.length} for b in r.data.bones},'objects':[o.name for o in c.objects if any(x in o.name.lower() for x in ['sleeve','cuff','bottle','palm','wrist','upper','arm','hand','neck'])]}
