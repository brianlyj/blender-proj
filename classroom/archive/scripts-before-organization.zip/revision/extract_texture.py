import bpy,json
from pathlib import Path
p=Path(r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom\revision')
for name in ['hair','face','Texture_0']:
 m=bpy.data.materials[name]
 for n in m.node_tree.nodes:
  if n.type=='TEX_IMAGE' and n.image:
   im=n.image;im.filepath_raw=str(p/(name+'-texture.png'));im.file_format='PNG';im.save();print(name,im.size[:],flush=True)
