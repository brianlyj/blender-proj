import bpy
from pathlib import Path
from mathutils import Vector
root=Path(r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom\revision');s=bpy.data.scenes['Classroom | Golden Hour'];s.camera=bpy.data.objects['Camera | 10 second dance'];s.render.engine='BLENDER_EEVEE';s.render.resolution_x=720;s.render.resolution_y=960;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG'
for name,frame in [('Rest-clasped',1),('Dance-left',57),('Dance-right',69),('Dance-middle',121)]:
 s.frame_set(frame);s.render.filepath=str(root/(name+'.png'));bpy.ops.render.render(write_still=True,scene=s.name)
