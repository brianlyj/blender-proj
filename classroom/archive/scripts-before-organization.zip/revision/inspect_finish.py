import bpy
s=bpy.context.scene;rig=bpy.data.objects['MARI | refined character rig'];c=bpy.data.collections['05 Character | refined sports outfit']
result={'view':{'transform':s.view_settings.view_transform,'look':s.view_settings.look,'exposure':s.view_settings.exposure,'gamma':s.view_settings.gamma},'text_names':[t.name for t in bpy.data.texts],'action':rig.animation_data.action.name,'objects':len(c.objects),'bones':len(rig.data.bones),'unweighted':[o.name for o in c.objects if o.type=='MESH' and not o.vertex_groups]}
