import bpy,json
from pathlib import Path
r=Path(r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom\revision')
face=bpy.data.objects['R2 | Face | sculpted anime'];eyes=bpy.data.objects['R2 | Eyes | textured anime']
# Save mesh buffers for local topology analysis, without the scene's other content.
for o in [face,eyes]:
 d={'v':[list(v.co) for v in o.data.vertices],'p':[list(p.vertices) for p in o.data.polygons],'uv':[list(v.uv) for v in o.data.uv_layers.active.data]}
 (r/('face-topology.json' if o==face else 'eyes-topology.json')).write_text(json.dumps(d))
result={'topology_saved':True}
