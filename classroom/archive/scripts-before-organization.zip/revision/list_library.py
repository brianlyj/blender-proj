import bpy,json
p=r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom\revision\Reference-inspection.blend'
with bpy.data.libraries.load(p,link=False) as (src,dst):
 print(json.dumps(src.objects),flush=True)
