import runpy
from pathlib import Path
root=Path(r'C:\Users\ASUS\Downloads\mcp-1.0.3\classroom')
runpy.run_path(str(root/'render_previews.py'))
runpy.run_path(str(root/'render_animation.py'))
